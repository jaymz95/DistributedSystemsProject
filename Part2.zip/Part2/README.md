# DistributedSystemsProject James Mullarkey (G00345716)

GIT: https://github.com/jaymz95/DistributedSystemsProject


# Part 1

### Run the the Service jar> java -jar part1Server.jar

- runs Server


# Part 2

#### SwaggerHub : https://app.swaggerhub.com/apis/Jaymz954/UserAPI/1#free

## Commands

mvn package
java -jar target/user-1.0-SNAPSHOT.jar server userApiConfig.yaml

#### URL: http://localhost:9000/users/
To get first user and so on:
http://localhost:9000/users/1 