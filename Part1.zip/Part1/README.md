# DistributedSystemsProject James Mullarkey (G00345716)

GIT: https://github.com/jaymz95/DistributedSystemsProject

### Run the the Service jar> java -jar part1Service.jar

- runs Server

### Run the the Client jar> java -jar part1Client.jar

- runs client
- outputs menu options to 1) Create Account or 2) Sign In
- then enter sign in or new account details